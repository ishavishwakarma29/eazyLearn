var questionNum = 2;
const questions = document.getElementsByClassName("ques-wrrapper")[0].innerHTML;

function addCode() {
  document.getElementById("add_to_me").innerHTML += 
  " <textarea class='que' type='text'> Question "+questionNum+" </textarea>"
  document.getElementById("add_to_me").innerHTML += questions;
  questionNum++;
}